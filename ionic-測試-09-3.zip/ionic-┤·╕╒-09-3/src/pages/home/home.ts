import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, URLSearchParams } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	items:any;
	
	constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {
		let params: URLSearchParams = new URLSearchParams();
		params.set('type', '3');

		this.http.get('http://140.131.115.72', {search: params})			
			.subscribe(
				(data) => {this.items=data.json();},
				(err) => {this.showAlert();}
			);			
	}


	showAlert() {
		let alert = this.alertCtrl.create({
			title: '資料取得失敗!',
			subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
			buttons: ['OK']
		});
		alert.present();
	}
}
