import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
	//--------------
    // 宣告成員
	//--------------
	items:Array<Object>=[];
	
	
	//--------------
	// 建構元函式
	//--------------
    constructor(public navCtrl: NavController) {
        this.items.push({'picName':'a.jpg', 'title':'真正的美，作假不得', 'detail':'幾年來，幾乎所有的竹科企業我都去過了，和企業的人有所接觸後，我才知道...'});
        this.items.push({'picName':'b.jpg', 'title':'找回人與人的感覺', 'detail':'我現在不問工程師有沒有去聽音樂、看展覽，反而是問他們...'});
        this.items.push({'picName':'c.jpg', 'title':'週休回來做自己', 'detail':'現在台灣過週休二日，好像非要全家去吃一個餐廳、到哪裡去看薰衣草、喝咖啡，全部整套，然後...'});	  			
    }
}
