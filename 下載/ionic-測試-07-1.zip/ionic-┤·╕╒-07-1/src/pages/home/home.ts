import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    //-----------------
    // Member
    //-----------------
    items:Array<Object>=[
        {'name':'王小明', 'pic':'a1.jpg'}, 
        {'name':'陳小華', 'pic':'a2.jpg'},
        {'name':'李小強', 'pic':'a3.jpg'},
        {'name':'周小花', 'pic':'a4.jpg'}
    ];


    //-----------------
    // Constructor
    //-----------------
    constructor(public navCtrl: NavController,
        private toastCtrl: ToastController) {}

    //-----------------
    showInfo(name) {
        let toast = this.toastCtrl.create({
            message: 'User was added successfully, '+name,
            duration: 3000,
            position: 'bottom'
        });

        toast.onDidDismiss(() => {
            console.log('Dismissed toast');
        });

       toast.present();
    }
}
