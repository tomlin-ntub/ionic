import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';


@IonicPage()
@Component({
  selector: 'page-detail',
  templateUrl: 'detail.html',
})
export class Detail {
	//--------------
    // 宣告成員
	//--------------
	picName:string=null;
    title:string=null;
	fullText:string=null;

  
  	//--------------
	// 建構元函式
	//--------------
    constructor(public navCtrl: NavController, public navParams: NavParams) {
		this.picName=navParams.get("picName");	
	    this.title=navParams.get("title");
	    this.fullText=navParams.get("fullText");
    }
}
