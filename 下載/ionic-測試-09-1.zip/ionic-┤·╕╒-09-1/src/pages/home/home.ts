import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/Http';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	items:any;
	
	constructor(public navCtrl: NavController, public http:Http) {
		this.http.get('http://140.131.115.72')			
			.subscribe(response => {
				this.items=response.json();
			});			
	}

}
