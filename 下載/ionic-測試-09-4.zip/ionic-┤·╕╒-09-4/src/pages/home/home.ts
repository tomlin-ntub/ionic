import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, URLSearchParams } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	userName:string;
	password:string;
	returnCode:any;

	//----------------------------------------------------------------	
	constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {}


	//----------------------------------------------------------------
	sendData(){
		// 傳給主機的參數
		let params: URLSearchParams = new URLSearchParams();
		params.set('userName', this.userName);
		params.set('password', this.password);

		this.http.get('http://140.131.115.72/sendDataTest', {search: params})			
			.subscribe(
				(data) => {
					this.returnCode=data.json();
					this.showConfirm();
					this.userName="";
					this.password="";
				},
				(err) => {this.showAlert();}
			);	
	}


	//----------------------------------------------------------------
	showAlert() {
		let alert = this.alertCtrl.create({
			title: '資料取得失敗!',
			subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
			buttons: ['OK']
		});
		alert.present();
	}

	//----------------------------------------------------------------
	showConfirm() {
		let alert = this.alertCtrl.create({
			title: '資料傳送成功!',
			subTitle: '已將資料傳送給主機.',
			buttons: ['OK']
		});
		alert.present();
	}	
}
