import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員    
    //----------------------------------    
    items:any;


    //----------------------------------
    // 建構元    
    //----------------------------------    
    constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {
        this.loadData();	
    }


    //----------------------------------
    // 讀取主機資料
    //----------------------------------            
    loadData(){
        //**網址請自行修改    
        this.http.get('http://192.168.56.1', {})			
            .subscribe(
                (data) => {this.items=data.json();},
                (err) => {this.showAlert();}
            );	
    }


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showAlert() {
        let alert = this.alertCtrl.create({
            title: '資料取得失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------
}