import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, URLSearchParams } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員     
    //----------------------------------    
    items:any;
    city:string="台北";

    //----------------------------------
    // 建構元    
    //----------------------------------    
    constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {
        this.loadData(this.city);	
    }


    //----------------------------------
    // 讀取主機資料
    //----------------------------------            
    loadData(city){
        // 傳給主機的參數
        let params: URLSearchParams = new URLSearchParams();
        params.set('city', city);

        this.http.get('http://192.168.56.1', {search: params})			
            .subscribe(
                (data) => {
                    this.items=data.json();

                    if(this.items.length==0){
                        this.showNotFound();
                        return;
                    }
                },
                (err) => {this.showAlert();}
            );	
    }


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showAlert() {
        let alert = this.alertCtrl.create({
            title: '資料取得失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------


    //----------------------------------
    // 顯示無符合資料訊息
    //----------------------------------
    showNotFound() {
        let alert = this.alertCtrl.create({
            title: '無符合資料!',
            subTitle: '目前資料庫無符合條件的資料.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------    
}
