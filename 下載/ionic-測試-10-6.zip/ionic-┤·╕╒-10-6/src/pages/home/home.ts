import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, URLSearchParams } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員     
    //----------------------------------    
    name:string;
    city:string;
    author:string;

    //----------------------------------
    // 建構元    
    //----------------------------------    
    constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {}


    //----------------------------------
    // 寫入資料
    //----------------------------------            
    writeData(){
        if(this.name=="" || this.city=="" || this.author==""){
            this.showNoEntry();
            return;
        }

        // 傳給主機的參數
        let params: URLSearchParams = new URLSearchParams();
        params.set('name', this.name);
        params.set('city', this.city);
        params.set('author', this.author);                

        this.http.get('http://192.168.56.1/writeFood', {search: params})			
            .subscribe(
                (data) => {
                    let rtn=data.json();

                    if(rtn.code==0){
                        this.showSuccess(); 
                        this.name="";
                        this.city="";
                        this.author="";                       
                    }else{
                        this.showFail();
                    }
                },
                (err) => {this.showAlert();}
            );	
    }


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showNoEntry() {
        let alert = this.alertCtrl.create({
            title: '請輸入資料!',
            subTitle: '請先輸入資料再上傳.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showAlert() {
        let alert = this.alertCtrl.create({
            title: '資料寫入失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------


    //----------------------------------
    // 顯示寫入成功訊息
    //----------------------------------
    showSuccess() {
        let alert = this.alertCtrl.create({
            title: '寫入成功!',
            subTitle: '資料寫入成功.',
            buttons: ['OK']
        });
        alert.present();
    }


    //----------------------------------
    // 顯示寫入失敗訊息
    //----------------------------------
    showFail() {
        let alert = this.alertCtrl.create({
            title: '寫入失敗!',
            subTitle: '資料寫入失敗.',
            buttons: ['OK']
        });
        alert.present();
    }    
    //----------------------------------    
}
