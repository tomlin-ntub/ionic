import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/http';
import { AlertController } from 'ionic-angular';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員
    //----------------------------------    
    name:string="";
    city:string="";
    author:string=""; 
    selectedImageFiles:any;

    //----------------------------------
    // 建構元
    //----------------------------------
    constructor(public navCtrl: NavController, 
        public http: Http,
        public alertCtrl: AlertController) {
        this.selectedImageFiles=[];
    }

    //----------------------------------
    // 上傳圖片
    //----------------------------------
    upload() {
        // 如果未輸入資料
        if(this.name=="" || this.city=="" || this.author==""){
            this.showNoEntry();
            return;
        }      

        if (this.selectedImageFiles[0]) {
            let input = new FormData();

            // 傳給主機的圖片
            for(var i=0; i<this.selectedImageFiles.length; i++){
                input.append("pictures", this.selectedImageFiles[i]);
            }		      

            // 傳給主機的文字
            input.append('name', this.name);
            input.append('city', this.city);
            input.append('author', this.author);
     
            //***改主機位址***
            this.http.post("http://120.97.15.192/writeFood", input)
                .subscribe(
                    (data) => {
                        //接收主機回傳代碼
                        let rtn=data.json();
                        
                        if(rtn.code==0){
                            //如果寫入成功
                            this.showWriteSuccess();
                            this.name="";
                            this.city="";
                            this.author="";                                 
                        }else if(rtn.code==-1){
                            //如果寫入失敗
                            this.showWriteFail();
                        }                                   
                    },
                    (err) => {
                        //如果連結主機失敗
                        this.showConnectionFail();
                    }
                );	
        }else{
           this.showNoPhoto(); 
        }
    }

    //----------------------------------
    // 加入圖片
    //----------------------------------
    imageUploaded(event){
        this.selectedImageFiles.push(event.file);
    }
	
    //----------------------------------
    // 移除圖片
    //----------------------------------
    imageRemoved(event){
        let index = this.selectedImageFiles.indexOf(event.file);		
        if( index > -1) {
            this.selectedImageFiles.splice(index, 1);
        }		
    }


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showNoEntry() {
        let alert = this.alertCtrl.create({
            title: '請輸入資料!',
            subTitle: '請先輸入資料再上傳.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------


    //----------------------------------
    // 連線失敗
    //----------------------------------
    showConnectionFail() {
        let alert = this.alertCtrl.create({
            title: '連線失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }

    //----------------------------------
    // 尚未選擇照片
    //----------------------------------
    showNoPhoto() {
        let alert = this.alertCtrl.create({
            title: '尚未選擇照片!',
            subTitle: '請先提供一張照片再繼續註冊.',
            buttons: ['OK']
        });
        alert.present();
    }    

    //----------------------------------
    // 寫入失敗
    //----------------------------------
    showWriteFail() {
        let alert = this.alertCtrl.create({
            title: '寫入失敗!',
            subTitle: '資料寫入失敗, 請檢查圖片是否超過2M.',
            buttons: ['OK']
        });
        alert.present();
    }

    //----------------------------------
    // 寫入成功
    //----------------------------------
    showWriteSuccess() {
        let alert = this.alertCtrl.create({
            title: '寫入成功!',
            subTitle: '已成功寫入.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------    	 
}