import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

//-----------------
// 增加匯入服務
//-----------------
import {BookService} from '../../providers/book-service';


@Component({
    selector: 'page-home',
    templateUrl: 'home.html',
    providers: [BookService]    /* 增加 */ 
})
export class HomePage {
    //------------------
	// 宣告成員
	//------------------
    private books:any;
  
  
    //--------------------
	// 宣告建構元
	//--------------------
    constructor(public navCtrl: NavController, private bookService: BookService) {
	    this.loadBooks();
    }
  
  
    //---------------------
	// 宣告函式
	//---------------------
	loadBooks(){
	    this.bookService.load()
	        .then(data => {
		        this.books = data;
	        });
	}
}
