import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http, URLSearchParams, RequestOptions, Headers } from '@angular/Http';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	userName:string;
	password:string;
	returnCode:any;

	//----------------------------------------------------------------	
	constructor(public navCtrl: NavController, public http:Http, public alertCtrl: AlertController) {}


	//----------------------------------------------------------------
	register(){
		// 改為自己的主機
		let url='192.168.56.1';
	
		// 傳給主機的參數
		let headers = new Headers({ 'Content-Type': 'application/json' });
	    let options = new RequestOptions({ headers: headers });
		let data={'username':this.userName, 'password':this.password};
		
		this.http.post(url, data, options)			
			.subscribe(
				(data) => {
					let ret=data.json();     //接收主機回傳代碼

					if(ret.code==0){         //如果成功註冊
						this.showSuccess();
						this.userName='';
						this.password='';
						return;
					}else{                   //如果註冊失敗 
						this.showFail();
						return;
					}
				},
				(err) => {this.showAlert();}
			);	
	}


	//----------------------------------------------------------------
	showAlert() {
		let alert = this.alertCtrl.create({
			title: '連線失敗!',
			subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
			buttons: ['OK']
		});
		alert.present();
	}

	//----------------------------------------------------------------
	showSuccess() {
		let alert = this.alertCtrl.create({
			title: '註冊成功!',
			subTitle: '帳號/密碼已成功註冊',
			buttons: ['OK']
		});
		alert.present();
	}	

	//----------------------------------------------------------------
	showFail() {
		let alert = this.alertCtrl.create({
			title: '註冊失敗!',
			subTitle: '帳號/密碼註冊失敗',
			buttons: ['OK']
		});
		alert.present();
	}		
}
