import { NgModule } from '@angular/core';
import { Detail } from './detail';

@NgModule({
    declarations: [
        Detail,
    ],
    exports: [
        Detail
    ]
})
export class DetailModule {}
