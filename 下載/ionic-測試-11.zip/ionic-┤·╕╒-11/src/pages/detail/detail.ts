import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

@IonicPage()
@Component({
    selector: 'page-detail',
    templateUrl: 'detail.html',
})

export class Detail {
    //----------------------
	// 成員
	//----------------------
    title:string=null;
    author:string=null;
    shortDesc:string=null;
    desc:string=null;
    imgURL:string=null; 


    //----------------------
	//  建構元
	//----------------------	
    constructor(public navCtrl: NavController, public navParams: NavParams) {
	    //取得傳入參數並存在成員中
	    this.title=navParams.get("title");
	    this.author=navParams.get("author");
	    this.shortDesc=navParams.get("shortDesc");
	    this.desc=navParams.get("desc");
	    this.imgURL=navParams.get("imgURL");	  
    }

	
    ionViewDidLoad() {}
}