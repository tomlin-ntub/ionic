import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

//------------------------
// 增加匯入
//------------------------
import {BookService} from '../../providers/book-service';
import {Detail} from '../detail/detail'

@Component({
    selector: 'page-home',
    templateUrl: 'home.html',
    providers: [BookService]    /* 增加 */ 
})
export class HomePage {
    //------------------
	// 成員
	//------------------
    private books:any;
  
  
    //--------------------
	// 建構元
	//--------------------
    constructor(public navCtrl: NavController, private bookService: BookService) {
	    this.loadBooks();
    }
  
  
    //---------------------
	// 函式(載入網站內容)
	//---------------------
	loadBooks(){
	    this.bookService.load()
	        .then(data => {
		        this.books = data;
	        });
	}
	
    //---------------------
	// 函式(轉開詳細頁面)
	//---------------------	
	redirect=function(title, author, shortDesc, desc, imgURL) {
        this.navCtrl.push(Detail, {title:title, author:author, shortDesc:shortDesc, desc:desc, imgURL:imgURL});
    }; 
}
