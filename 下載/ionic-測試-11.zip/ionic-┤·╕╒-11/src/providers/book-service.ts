import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class BookService {
    //-------------------
	// 宣告建構元
	//-------------------
    constructor(public http: Http) {}
  
  
    //-------------------
	// 宣告函式
	//------------------- 
    load() {
	    return new Promise(resolve => {
		    this.http.get('http://105stu.ntub.edu.tw')
		        .map(res => res.json())
		        .subscribe(data => {resolve(data);});
	    });
	}
}
