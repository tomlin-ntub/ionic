import { Component } from '@angular/core';
import { NavController, ToastController } from 'ionic-angular';
import { Http } from '@angular/http';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    selectedImageFiles:any;

    constructor(public navCtrl: NavController, 
        public http: Http,
        private toastCtrl: ToastController) {
        this.selectedImageFiles=[];
    }


    //----------------------------------
    // 上傳圖片
    //----------------------------------
    upload() {		
        if (this.selectedImageFiles[0]) {	
            let input = new FormData();

            for(var i=0; i<this.selectedImageFiles.length; i++){
                input.append("pictures", this.selectedImageFiles[i]);
            }		      
     
            //***改主機位址***
            this.http.post("http://105stu.ntub.edu.tw", input)
                .subscribe(
                    (data) => {
                        this.successToast();                   
                    },
                    (err) => {
                        this.failToast();
                    }
                );	
        }
    }

    //----------------------------------
    // 加入圖片
    //----------------------------------
    imageUploaded(event){
        this.selectedImageFiles.push(event.file);
    }
	
    //----------------------------------
    // 移除圖片
    //----------------------------------
    imageRemoved(event){
        let index = this.selectedImageFiles.indexOf(event.file);		
        if( index > -1) {
            this.selectedImageFiles.splice(index, 1);
        }		
    }

    //----------------------------------
    // 顯示成功訊息
    //----------------------------------
    successToast() {
        let toast = this.toastCtrl.create({
            message: '上傳成功',
            duration: 3000,
            position: 'bottom'
        });

        toast.present();
    }

    //----------------------------------
    // 顯示失敗訊息
    //----------------------------------
    failToast() {
        let toast = this.toastCtrl.create({
            message: '上傳成功',
            duration: 3000,
            position: 'bottom'
        });

        toast.present();
    }  
}