import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Http } from '@angular/http';
import { AlertController } from 'ionic-angular';

@Component({
    selector: 'page-home',
    templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員
    //----------------------------------    
    userid:string;
    name:string;
    password:string; 
    selectedImageFiles:any;

    //----------------------------------
    // 建構元
    //----------------------------------
    constructor(public navCtrl: NavController, 
        public http: Http,
        public alertCtrl: AlertController) {
        this.selectedImageFiles=[];
    }

    //----------------------------------
    // 上傳圖片
    //----------------------------------
    upload() {		
        if (this.selectedImageFiles[0]) {
            let input = new FormData();

            // 傳給主機的圖片
            for(var i=0; i<this.selectedImageFiles.length; i++){
                input.append("pictures", this.selectedImageFiles[i]);
            }		      

            // 傳給主機的文字
            input.append('userid', this.userid);
            input.append('name', this.name);
            input.append('password', this.password);
     
            //***改主機位址***
            this.http.post("http://120.97.15.192", input)
                .subscribe(
                    (data) => {
                        let rtn=data.json();
                        if(rtn.code==0){
                            this.showRegisterSuccess();
                        }else if(rtn.code==-1){
                            this.showRegisterFail();
                        }                                   
                    },
                    (err) => {
                        this.showConnectionFail();
                    }
                );	
        }else{
           this.showNoPhoto(); 
        }
    }

    //----------------------------------
    // 加入圖片
    //----------------------------------
    imageUploaded(event){
        this.selectedImageFiles.push(event.file);
    }
	
    //----------------------------------
    // 移除圖片
    //----------------------------------
    imageRemoved(event){
        let index = this.selectedImageFiles.indexOf(event.file);		
        if( index > -1) {
            this.selectedImageFiles.splice(index, 1);
        }		
    }

    //----------------------------------
    // 連線失敗
    //----------------------------------
    showConnectionFail() {
        let alert = this.alertCtrl.create({
            title: '連線失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }

    //----------------------------------
    // 尚未選擇照片
    //----------------------------------
    showNoPhoto() {
        let alert = this.alertCtrl.create({
            title: '尚未選擇照片!',
            subTitle: '請先提供一張照片再繼續註冊.',
            buttons: ['OK']
        });
        alert.present();
    }    

    //----------------------------------
    // 註冊失敗
    //----------------------------------
    showRegisterFail() {
        let alert = this.alertCtrl.create({
            title: '註冊失敗!',
            subTitle: '請使用其他帳號名稱重新註冊.',
            buttons: ['OK']
        });
        alert.present();
    }

    //----------------------------------
    // 註冊成功
    //----------------------------------
    showRegisterSuccess() {
        let alert = this.alertCtrl.create({
            title: '註冊成功!',
            subTitle: '已成功註冊.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------    	 
}