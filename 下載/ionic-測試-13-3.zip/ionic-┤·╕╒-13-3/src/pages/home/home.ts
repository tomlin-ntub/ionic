import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ToastController } from 'ionic-angular';


declare var google;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  //---------------------------------------------------
  // 成員  
  //---------------------------------------------------
  @ViewChild('mapContainer') mapContainer: ElementRef;
  map: any;

  center:any={
    'lat':25.042375,
    'lng':121.525383,
    'name':'北商大'
  };  


  //--------------------------------------------------- 
  // 建構元
  //--------------------------------------------------- 
  constructor(public navCtrl: NavController, public toastCtrl: ToastController) {}
  

  //---------------------------------------------------  
  // 畫面完成後執行
  //--------------------------------------------------- 
  ionViewWillEnter() {
    this.displayGoogleMap();
    this.addMarkersToMap();
  }


  //--------------------------------------------------- 
  // 顯示Google地圖
  //---------------------------------------------------   
  displayGoogleMap() {
    let latLng = new google.maps.LatLng(this.center.lat, this.center.lng);

    let mapOptions = {
      center: latLng,
      disableDefaultUI: true,
      zoom: 17,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    this.map = new google.maps.Map(this.mapContainer.nativeElement, mapOptions);
  }


  //--------------------------------------------------- 
  // 加入圖釘
  //---------------------------------------------------  
  addMarkersToMap() {
    var position = new google.maps.LatLng(this.center.lat, this.center.lng);
    var myMarker = new google.maps.Marker({position:position, title:this.center.name});
    
    myMarker.setMap(this.map);    
    this.addInfoWindowToMarker(myMarker);
  }


  //--------------------------------------------------- 
  // 加入訊息視窗
  //---------------------------------------------------  
  addInfoWindowToMarker(marker) {
    var infoWindowContent = 
        '<div id="content"><h1 id="firstHeading" class="firstHeading">' + 
        marker.title + 
        '</h1><p><input type="text" id="myTxt"></input></p>' + 
        '<button id="myBtn" style="height:30px;background:#550000;color:#fff">Button</button></div>';

    var infoWindow = new google.maps.InfoWindow({
      content: infoWindowContent
    });

    marker.addListener('click', () => {
      infoWindow.open(this.map, marker);
    });
    
    google.maps.event.addListenerOnce(infoWindow, 'domready', () => {
        //如果myBtn被點擊, 將marker.title及輸入值當為參數傳給自定函數
        document.getElementById('myBtn').addEventListener('click', () => {
            var myTxt=(<HTMLInputElement>document.getElementById("myTxt")).value;            
            this.presentToast(marker.title, myTxt);
        });
    }); 
  }


  //---------------------------------------------------  
  // 自訂函數, 用來接收使用者點擊的infoWindow輸入
  //---------------------------------------------------  
  presentToast(title, myTxt) {
    let msg="參數:" + title + "," + myTxt;

    let toast = this.toastCtrl.create({
      message: msg,
      duration: 3000
    });
    toast.present();
  }
  //---------------------------------------------------    
}