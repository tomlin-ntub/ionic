import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  //------------------------------
  // 成員
  //------------------------------
  id:string;
  name:string;  


  //------------------------------
  // 建構元
  //------------------------------
  constructor(public navCtrl: NavController, private fb: Facebook) {}


  //------------------------------
  // 登入
  //------------------------------
  login(){
      this.fb.login(['public_profile'])
          .then((res: FacebookLoginResponse) => {
              this.fb.api('/v2.9/me?fields=id,name,gender', [])
                  .then((profile)=> {
                       this.id=profile.id;
                       this.name=profile.name;
                  })
                  .catch(e=>{                       
                       this.id='id取得失敗';
                       this.name='name取得失敗';
                  });            
          })
          .catch(e => {
              this.id='登入失敗';
              this.name='登入失敗';
          });
  }


  //------------------------------
  // 登出
  //------------------------------
  logout(){
      this.fb.logout()
          .then(()=>{
              this.id='已登出';
              this.name='已登出';
          })
          .catch(e => {
              this.id='尚未登入';
              this.name='尚未登入';
          });
  }  
}