import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { MyService } from '../../providers/my-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    //----------------------------------
    // 成員     
    //----------------------------------    
    items:any;
    city:string="台北";

    //----------------------------------
    // 建構元    
    //----------------------------------    
    constructor(public navCtrl: NavController, 
      public alertCtrl: AlertController,
      private myService: MyService) {
        this.loadData(this.city);
    }


    //----------------------------------
    // 讀取主機資料
    //----------------------------------            
    loadData(city){
        this.myService.load(city).then(
            (results) => {  
                if(results==-1){
                    this.showAlert();
                    return;
                }else{                                          
                    this.items = results;
                    if(this.items.length==0){
                        this.showNotFound();
                        return;
                    }
                }    
            }
        );
    }


    //----------------------------------
    // 顯示讀取失敗訊息
    //----------------------------------
    showAlert() {
        let alert = this.alertCtrl.create({
            title: '資料取得失敗!',
            subTitle: '請確定網路狀態, 或是主機是否提供服務中.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------


    //----------------------------------
    // 顯示無符合資料訊息
    //----------------------------------
    showNotFound() {
        let alert = this.alertCtrl.create({
            title: '無符合資料!',
            subTitle: '目前資料庫無符合條件的資料.',
            buttons: ['OK']
        });
        alert.present();
    }
    //----------------------------------    
}
