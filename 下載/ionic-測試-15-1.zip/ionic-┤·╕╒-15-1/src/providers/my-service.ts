import { Injectable } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';  /* 加入 URLSearchParams */
import 'rxjs/add/operator/map';


@Injectable()
export class MyService {
    //-------------------------
    // 建構元
    //-------------------------
    constructor(public http: Http) {}

    //-------------------------------------
    // 載入資料函式
    //-------------------------------------
    load(city){
        return new Promise(resolve => {
            // 傳給主機的參數
            let params: URLSearchParams = new URLSearchParams();
            params.set('city', city);    

            this.http.get('http://192.168.56.1', {search: params})	
                .map(res => res.json())
                .subscribe(
                    (data) => {                           
                        resolve(data);  //成功取回資料                              
                    },
                    (err) => {
                        resolve(-1);    //取回資料失敗
                    }
                );
            });
    }
    //-------------------------------------
}
