var express = require('express');
var router = express.Router();
var mysql = require('mysql');
//------------------
// 載入資料庫連結
//------------------
var pool = require('./lib/db.js');

//------------------
// 回應GET請求
//------------------
router.get('/', function(req, res, next) {
    //接收傳來的參數	
    var name=req.query.name;
    var city=req.query.city;
	var author=req.query.author;
	
	console.log(name);
	console.log(city);
	console.log(author);

    //產生一個物件
    var newData={
        name:name,
        city:city,
		author:author
    }

    //寫入資料庫
    pool.query('INSERT INTO foods SET ?', newData, function(err, rows, fields) {
        if (err){
            rtn={'code':-1};
            res.json(rtn);     //回傳失敗代號
        }else{
            rtn={'code':0};
            res.json(rtn);     //回傳成功代號
        }
    });
});

module.exports = router;