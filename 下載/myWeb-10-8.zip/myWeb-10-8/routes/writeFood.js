var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var fs = require('fs');

//--------------------------------
// 引用multer, easyimg外掛
//-------------------------------- 
var multer  = require('multer');
var easyimg = require('easyimage');

//------------------
// 載入資料庫連結
//------------------
var pool = require('./lib/db.js');


//宣告上傳存放空間及檔名更改
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public\\images');
    },
    filename: function (req, file, cb) {
        var fileName = Date.now() + "--" + file.originalname;
        cb(null, fileName);
    }
})

//使用multer上傳物件
var upload = multer({ storage: storage })

  
/* POST home page. */
router.post('/', function(req, res) {
	//--------------------------
    // 產生multer的上傳物件
	//--------------------------
    var maxSize=2*1024*1024;  //設定最大可接受圖片大小(2M)
    var maxNumberOfImage=1;   //最多上傳圖片數

    var upload = multer({
        storage:storage,
        limits:{ fileSize: maxSize }
    }).array('pictures', maxNumberOfImage);    //表單中的檔案名稱

    //---------------
    // 上傳檔案
    //---------------    
    upload(req, res, function (err) {
        if (err) {   
            console.log(err);
            res.json({code:-1});  //如果失敗
            return;
        }

		//---------------------
		// 如果成功
		//---------------------	
		var filename=null;  //原圖名稱
		var thembnailName;  //裁成正方形圖片名稱
		var cropedName;     //裁切(800*500)圖片名稱
		
		if (typeof req.files != 'undefined'){			 
			for(var i=0; i<req.files.length; i++){  //逐一處理上傳圖片			
				//--------------------------
				// 顯示成功上傳的圖片資訊
				//--------------------------
				var file = req.files[i];
				console.log('文件類型：%s', file.mimetype);
				console.log('原始文件名：%s', file.originalname);
				console.log('文件大小：%s', file.size);
				console.log('文件保存路徑：%s', file.path);
			
				filename = file.path.replace(/^.*[\\\/]/, '')
				var path=file.path.substring(0, file.path.length-filename.length);
				console.log("僅路徑:", path);
				//--------------------------

		

				//--------------------------	
				// 用easyimg產生小方圖
				//--------------------------
				thembnailName=path+"thumbnail-"+filename;
				
				easyimg.thumbnail({
					src:file.path, 
					dst:thembnailName,
					width:300, height:300,
					x:0, y:0
				}).then(
					function(image) {
						console.log('已產生小方圖: ' + image.width + ' x ' + image.height);
					},
					function (err) {
						console.log(err);
					}
				);			
				//--------------------------


				//--------------------------	
				// 用easyimg調整大小並裁剪圖片
				//--------------------------	
				cropedName=path+"croped-"+filename;
				
				easyimg.rescrop({
					src:file.path, 
					dst:cropedName,
					width:800, height:550,
					cropwidth:800, cropheight:500,
					x:0, y:0
				}).then(
					function(image) {
						console.log('已產生調整大小並裁剪後的圖片: ' + image.width + ' x ' + image.height);
					},
					function (err) {
						console.log(err);
					}
				);	
			}		
			//-------------------------------------------------------
		}else{
			res.json({code:-2});   //回傳尚未選照片訊息
			return;
		}	

		// 上傳成功, 接著取得使用者傳來的參數
		var name=req.param("name");
		var city=req.param("city");
		var author=req.param("author");
		var thumbnail=thembnailName;		
		var imgURL=cropedName;		
		var uploadDateTime= new Date();
        var lastUpdate= new Date(uploadDateTime.getYear()+1900, uploadDateTime.getMonth(), uploadDateTime.getDate())
		
		console.log('------------------');
		console.log(name);
		console.log(city);
		console.log(author);
		console.log(thumbnail);
		console.log(imgURL);
		console.log(uploadDateTime);
        console.log(lastUpdate);
		console.log('------------------');

		
		// 建立一個新資料物件
		var newData={
			name:name,
			city:city,
			author:author,
			thumbnail:thumbnail,
			imgURL:imgURL,
			uploadDateTime:uploadDateTime,
			lastUpdate:lastUpdate
		}   

		// 將前項物件寫入資料表
		pool.query('INSERT INTO foods SET ?', newData, function(err, rows, fields) {
			if (err){
				//刪除先前已上傳的圖片
				var deleteFile=null;
				
				deleteFile='public/images/' + filename;
				fs.unlink(deleteFile, (err) => {
					if (err) console.log('圖片檔(原圖)未上傳');
					console.log('已刪除圖片檔(原圖)');
				});		
				
				deleteFile='public/images/' + "croped-" + filename;
				fs.unlink(deleteFile, (err) => {
					if (err) console.log('圖片檔(裁剪圖)未上傳');
					console.log('已刪除圖片檔(裁剪圖)');
				});	
				
				var deleteFile='public/images/' + "thumbnail-" + filename;
				fs.unlink(deleteFile, (err) => {
					if (err) console.log('圖片檔(小方圖)未上傳');
					console.log('已刪除圖片檔(小方圖)');
				});	
					
				console.log('***寫入失敗***');
				console.log(err);
				
				res.json({code:-1});   //回傳失敗訊息
			}else{			
				console.log('***寫入成功***');
				
				res.json({code:0});   //回傳成功訊息
			}
		});       
    });	
});

module.exports = router;