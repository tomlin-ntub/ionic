var express = require('express');
var router = express.Router();

//--------------------------------
// 引用multer, easyimg外掛
//-------------------------------- 
var multer  = require('multer');
var easyimg = require('easyimage');


//宣告上傳存放空間及檔名更改
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public\\uploads');
    },
    filename: function (req, file, cb) {
        var fileName = Date.now() + "--" + file.originalname;
        cb(null, fileName);
    }
})

//使用multer上傳物件
var upload = multer({ storage: storage })

  
/* POST home page. */
router.post('/', function(req, res) {
	//--------------------------
    // 產生multer的上傳物件
	//--------------------------
    var maxSize=1*1024*1024;  //設定最大可接受圖片大小(1M)
    var maxNumberOfImage=5;   //最多上傳圖片數

    var upload = multer({
        storage:storage,
        limits:{ fileSize: maxSize }
    }).array('pictures', maxNumberOfImage);    //表單中的檔案名稱

    //---------------
    // 上傳檔案
    //---------------    
    upload(req, res, function (err) {
        if (err) {   
            console.log(err);
            res.json({code:-1});  //如果失敗
            return;
        }

		//---------------------
		// 如果成功
		//---------------------			
		if (typeof req.files != 'undefined'){			 
			for(var i=0; i<req.files.length; i++){  //逐一處理上傳圖片
				var filename=null;
			
				//--------------------------
				// 顯示成功上傳的圖片資訊
				//--------------------------
				var file = req.files[i];
				console.log('文件類型：%s', file.mimetype);
				console.log('原始文件名：%s', file.originalname);
				console.log('文件大小：%s', file.size);
				console.log('文件保存路徑：%s', file.path);
			
				filename = file.path.replace(/^.*[\\\/]/, '')
				var path=file.path.substring(0, file.path.length-filename.length);
				console.log("僅路徑:", path);
				//--------------------------

		

				//--------------------------	
				// 用easyimg產生小方圖
				//--------------------------
				var thembnailName=path+"thumbnail-"+filename;
				
				easyimg.thumbnail({
					src:file.path, 
					dst:thembnailName,
					width:300, height:300,
					x:0, y:0
				}).then(
					function(image) {
						console.log('已產生小方圖: ' + image.width + ' x ' + image.height);
					},
					function (err) {
						console.log(err);
					}
				);			
				//--------------------------


				//--------------------------	
				// 用easyimg調整大小並裁剪圖片
				//--------------------------	
				var cropedName=path+"croped-"+filename;
				
				easyimg.rescrop({
					src:file.path, 
					dst:cropedName,
					width:800, height:550,
					cropwidth:800, cropheight:500,
					x:0, y:0
				}).then(
					function(image) {
						console.log('已產生調整大小並裁剪後的圖片: ' + image.width + ' x ' + image.height);
					},
					function (err) {
						console.log(err);
					}
				);	
			}		
			//-------------------------------------------------------
		}   
		
        res.json({code:0});   //回傳成功訊息
        return;
        
    });	
});

module.exports = router;