var express = require('express');
var router = express.Router();

//再引用multer外掛, 
var multer  = require('multer');

//宣告上傳存放空間及檔名更改
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public\\uploads');
    },
    filename: function (req, file, cb) {
        var fileName = Date.now() + "--" + file.originalname;
        cb(null, fileName);
    }
})

//使用multer上傳物件
var upload = multer({ storage: storage })

  
/* POST home page. */
router.post('/', function(req, res) {
    //-----------------------------------------------
    // 產生multer的上傳物件
    //-----------------------------------------------
    var maxSize=1*1024*1024;  //設定最大可接受圖片大小(1M)
    var maxNumberOfImage=5;   //最多上傳圖片數

    var upload = multer({
        storage:storage,
        limits:{ fileSize: maxSize }
    }).array('pictures', maxNumberOfImage);    //表單中的檔案名稱

    //---------------
    // 上傳檔案
    //---------------    
    upload(req, res, function (err) {
        if (err) {   
            console.log(err);
            res.json({code:-1});  //如果失敗
            return;
        } else {            
            console.log('success');      
            res.json({code:0});   //如果成功
            return;
        }
    });	
});

module.exports = router;