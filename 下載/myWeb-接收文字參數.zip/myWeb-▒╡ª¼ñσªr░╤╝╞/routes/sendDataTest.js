var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
	var userName=req.query.userName;
	var password=req.query.password;
	console.log('------------------------');
	console.log('get');
	console.log(userName);
	console.log(password);
	
	data=[{'code':'0'}];	
	res.json(data);
});


/* POST home page. */
router.post('/', function(req, res, next) {
	var userName=req.body.userName;
	var password=req.body.password;
	console.log('------------------------');
	console.log('post');
	console.log(userName);
	console.log(password);	

	data=[{'code':'1'}];	
	res.json(data);	
});

	
module.exports = router;

