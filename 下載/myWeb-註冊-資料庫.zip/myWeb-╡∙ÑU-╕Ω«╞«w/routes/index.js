var express = require('express');
var router = express.Router();
var mysql = require('mysql');
//------------------
// 載入資料庫連結
//------------------
var pool = require('./lib/db.js');

//------------------
// 回應POST請求
//------------------
router.post('/', function(req, res, next) {
    //接收傳來的參數
	var username=req.body.username;
	var password=req.body.password;
	
	//產生一個物件
	var newData={
		username:username,
		password:password
	}

	//寫入資料庫
    pool.query('INSERT INTO user SET ?', newData, function(err, rows, fields) {
        if (err){
			rtn={'code':-1};
			res.json(rtn);     //回傳失敗代號
        }else{
			rtn={'code':0};
			res.json(rtn);     //回傳成功代號
        }
    });
});

	
module.exports = router;


